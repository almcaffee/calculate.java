/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math;
import java.util.*;
/**
 *
 * @author dev9
 */

public class basicCalc {
    
    public static void main(String[] args) {
        
        
        
    }

    public basicCalc() {
        this.tabulate = new mathPad();
    }
    
    private class mathPad {
       
        List<Double> numbers;
        String display;
        
        /* Clears contents after printing */
        void clear() {
            
            display = "";
            
            for(int i = numbers.size(); i > 0; i--) {
                numbers.remove(i);
            }
        }
        
    }
    
    private mathPad tabulate;
    
    /* adds to currently displayed text */
    private String currentArgs(String display, String inputTxt) {
      
        display += inputTxt;
        return display;
    }
    
    /* adds to currently calculated numbers */
    private List<Double> currentVariables(List<Double> numbers, double inputVar) {
        
        numbers.add(inputVar);
        return numbers;
    }
    
    private Double calculate(List<Double> numbers, char inputCalc){
        double result = 0;
        switch (inputCalc)
        {
            case '+': result = numbers.get(0) + numbers.get(1);
                break;
            case '-': result = numbers.get(0) - numbers.get(1);
                break;
            case '*': result = numbers.get(0) * numbers.get(1);
                break;
            case '/': result = numbers.get(0) / numbers.get(1);
                break;
            default: ;
        }
        
        /* Call display function for calculated value */
        /* Also should clear display string text */
        
        return result;
        /* System.out.println("The answer is " + result); */
    }
}
